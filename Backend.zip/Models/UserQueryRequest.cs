﻿namespace ADUserGroupManagerWeb.Models
{
    public class UserQueryRequest
    {
        public string Username { get; set; }
    }
}
