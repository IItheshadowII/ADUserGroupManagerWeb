﻿namespace ADUserGroupManagerWeb.Services
{
    public class PermissionAuthorizationHandler
    {
    }
}
